 <footer >  <!-- footer starts -->
        
            
            <div class="row footer-stuff">
            
                <div class="columns ">
                    
                    <p style="text-align:left;margin:2%;text-weight:none;"><strong style="color:yellow;align:center;font-size:20px;">Note:</strong><br>
                      > No delivery charges on order above Rs. 100.<br>
                      > Rs. 20 will be charged on delivery below Rs.100.<br>
                      > Cash on Delivery available.<br>
                      > Get your order within 30 minutes.<br></p>
	  
                    
                </div>
                
                <div class="columns ">
                
                    <strong style="text-align:center;color: #e82175;padding-bottom: 10px;display: block;">Other Links</strong>
                    <ul>
                        <li><a href="#">Ranchi</a></li>
                        <li><a href="#">Local Sites</a></li>
                        <li><a href="#">Queries</a></li>
                        <li><a href="#">Others</a></li>
                        
                    </ul>
                    
                </div>
                
                <div class="columns ">
                    
                    <div class="set3" style="margin: auto;">
            
                        <b style="display:block;margin-bottom:10px; text-align: center;">Follow Us:</b>
                      <div style="text-align: center;" class="menu2" >

                        <a href="twitter.com"><span class="fa-stack fa-lg">
                          <i class="fa fa-circle fa-stack-2x" style="color:#00C3FC;" ></i>
                          <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>

                        <a href="facebook.com"><span class="fa-stack fa-lg">
                          <i class="fa fa-circle fa-stack-2x" style="color:#345AA9;"></i>
                          <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>

                        <a href="linkedin.com"><span class="fa-stack fa-lg">
                          <i class="fa fa-circle fa-stack-2x" style="color:#0079B8;"></i>
                          <i class="fa fa-linkedin fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>

                        <a href="google+.com"><span class="fa-stack fa-lg">
                          <i class="fa fa-circle fa-stack-2x" style="color:#EC4D29;"></i>
                          <i class="fa fa-google-plus fa-stack-1x fa-inverse"></i>
                            </span>
                        </a>
                      </div>
                  </div>
                    <br>
                    <div class="join">
                        <a href="#" >Join Us</a>
                    </div>
                    
                    
                </div>
            
            </div>
            
        </footer>
            <div class="last">
                <p>Copyright &copy; 2016</p>
            </div>
</body>
</html>