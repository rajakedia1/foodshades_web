$('#slider').cycle({
    
    fx:   'scrollHorz',
    next: '#next',
    prev: '#prev',
    pager: '#pager',
    timeout: 2000,
    speed:  700
    
});